#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_NAME 80
#define MAX_MALOP 20

// MODULE 1: QUẢN LÝ GIẢNG VIÊN (SAFE)
typedef struct {
    int   id;
    char  maGiangVien[20];
    char  hoTen[MAX_NAME];      // Bounds protected with snprintf
    char  bangCap[20];          // Validated set
    float heSoBangCap;
    int   is_deleted;
} GiangVien;

// MODULE 2: QUẢN LÝ LỚP HỌC PHẦN (SAFE)
typedef struct {
    int         id;
    char        maLop[MAX_MALOP];  // Bounds protected with snprintf
    int         soTiet;
    float       heSoHocPhan;
    int         soLuongSinhVien;
    GiangVien  *gv_ptr;           // Safely tracked & nulled on delete
} LopHocPhan;

// MODULE 3: TÍNH TIỀN DẠY & THANH TOÁN (SAFE)
typedef struct {
    float heSoQuyMoLop;
    long long dinhMucTienChuan;   // 64-bit safe currency arithmetic
    int   nam;
} Config;

// Module 1 Function: Add Lecturer (SAFE)
GiangVien* add_lecturer_SAFE(int id, const char *maGV, const char *hoTen, const char *bangCap) {
    if (!maGV || !hoTen || !bangCap) return NULL;

    GiangVien *gv = (GiangVien*)malloc(sizeof(GiangVien));
    if (!gv) return NULL;

    gv->id = id;
    snprintf(gv->maGiangVien, sizeof(gv->maGiangVien), "%s", maGV);

    // FIX CWE-120: Bounds checking using snprintf to prevent buffer overflow
    snprintf(gv->hoTen, sizeof(gv->hoTen), "%s", hoTen);

    // FIX CWE-1288: Strict degree validation
    if (strcmp(bangCap, "GS") == 0)           gv->heSoBangCap = 2.0f;
    else if (strcmp(bangCap, "PGS") == 0)     gv->heSoBangCap = 1.8f;
    else if (strcmp(bangCap, "TIEN_SI") == 0) gv->heSoBangCap = 1.5f;
    else if (strcmp(bangCap, "THAC_SI") == 0) gv->heSoBangCap = 1.2f;
    else if (strcmp(bangCap, "CU_NHAN") == 0) gv->heSoBangCap = 1.0f;
    else {
        fprintf(stderr, "[SAFE ERROR] Invalid degree '%s'! Defaulting safely to CU_NHAN (1.0f)\n", bangCap);
        gv->heSoBangCap = 1.0f;
        bangCap = "CU_NHAN";
    }

    snprintf(gv->bangCap, sizeof(gv->bangCap), "%s", bangCap);
    gv->is_deleted = 0;
    return gv;
}

// Module 1 Function: Delete Lecturer (SAFE)
void delete_lecturer_SAFE(GiangVien **gv_pptr, LopHocPhan *lhp) {
    if (gv_pptr && *gv_pptr) {
        (*gv_pptr)->is_deleted = 1;
        // FIX CWE-416: Clear link in Class Section BEFORE freeing memory to prevent UAF
        if (lhp && lhp->gv_ptr == *gv_pptr) {
            lhp->gv_ptr = NULL;
            printf("[SAFE CLEANUP] Unlinked lecturer from class section before freeing memory.\n");
        }
        free(*gv_pptr);
        *gv_pptr = NULL; // Nullify caller pointer
    }
}

// Module 2 Function: Create Class Section (SAFE)
LopHocPhan* create_class_section_SAFE(int id, const char *maLop, int soTiet, float heSoHP, int svCount, GiangVien *gv) {
    if (!maLop) return NULL;

    LopHocPhan *lhp = (LopHocPhan*)malloc(sizeof(LopHocPhan));
    if (!lhp) return NULL;

    lhp->id = id;
    // FIX CWE-120: Bounds checking using snprintf
    snprintf(lhp->maLop, sizeof(lhp->maLop), "%s", maLop);
    lhp->soTiet = (soTiet > 0) ? soTiet : 0;
    lhp->heSoHocPhan = (heSoHP > 0.0f) ? heSoHP : 1.0f;
    lhp->soLuongSinhVien = (svCount > 0) ? svCount : 0;
    lhp->gv_ptr = (gv && !gv->is_deleted) ? gv : NULL; // Verify non-null & non-deleted
    return lhp;
}

// Module 3 Function: Calculate Salary E2E (SAFE)
long long calculate_e2e_salary_SAFE(LopHocPhan *lhp, Config *cfg) {
    // FIX CWE-476: Check for NULL pointer on class section and assigned lecturer
    if (!lhp || !cfg) {
        fprintf(stderr, "[SAFE ERROR] Class Section or Config is NULL!\n");
        return -1;
    }
    if (!lhp->gv_ptr || lhp->gv_ptr->is_deleted) {
        fprintf(stderr, "[SAFE BLOCKED] Class section '%s' has NO assigned lecturer! Cannot calculate salary.\n", lhp->maLop);
        return 0;
    }

    double heSoQuyMo = (lhp->soLuongSinhVien > 50) ? 0.2 : 0.0;
    // FIX CWE-190: 64-bit double & long long arithmetic preventing integer overflow
    double soTietQuyDoi = (double)lhp->soTiet * ((double)lhp->heSoHocPhan + heSoQuyMo);
    double tienDayDouble = soTietQuyDoi * (double)lhp->gv_ptr->heSoBangCap * (double)cfg->dinhMucTienChuan;

    return (long long)tienDayDouble;
}

void export_report_SAFE(GiangVien *gv, LopHocPhan *lhp, long long tienDay) {
    printf("[MOD-E2E SAFE REPORT] GV: %s (%s) | Lop: %s | Tiet: %d | Tien: %lld VND\n",
           gv ? gv->hoTen : "UNASSIGNED",
           gv ? gv->bangCap : "N/A",
           lhp ? lhp->maLop : "UNKNOWN",
           lhp ? lhp->soTiet : 0,
           tienDay);
}

int main(int argc, char *argv[]) {
    Config cfg = { .heSoQuyMoLop = 0.2f, .dinhMucTienChuan = 85000, .nam = 2025 };

    if (argc > 1) {
        if (strcmp(argv[1], "e2e_overflow") == 0) {
            printf("--- E2E TEST SAFE: CWE-120 Buffer Overflow ---\n");
            char long_name[120];
            memset(long_name, 'A', 119);
            long_name[119] = '\0';
            GiangVien *gv = add_lecturer_SAFE(1, "DU_GV01", long_name, "TIEN_SI");
            if (gv) {
                printf("[SAFE] GV Name truncated safely: %s (length: %zu)\n", gv->hoTen, strlen(gv->hoTen));
                free(gv);
            }
            return 0;
        } else if (strcmp(argv[1], "e2e_uaf") == 0) {
            printf("--- E2E TEST SAFE: CWE-416 Use-After-Free Blocked ---\n");
            GiangVien *gv = add_lecturer_SAFE(1, "DU_GV01", "Lionel Messi", "TIEN_SI");
            LopHocPhan *lhp = create_class_section_SAFE(1, "CNTT2024_01", 45, 1.0f, 60, gv);
            printf("[MOD-1] Created GV: %s\n", gv->hoTen);
            printf("[MOD-2] Assigned GV to Class: %s\n", lhp->maLop);
            
            // Delete GV safely
            delete_lecturer_SAFE(&gv, lhp);
            printf("[MOD-1] Deleted GV safely (Pointer nulled & unlinked)\n");

            // Calculate Salary safely
            printf("[MOD-3] Calculating Salary for Class...\n");
            long long tien = calculate_e2e_salary_SAFE(lhp, &cfg);
            export_report_SAFE(lhp->gv_ptr, lhp, tien);
            free(lhp);
            return 0;
        } else if (strcmp(argv[1], "e2e_null") == 0) {
            printf("--- E2E TEST SAFE: CWE-476 Null Pointer Handled ---\n");
            LopHocPhan *lhp = create_class_section_SAFE(1, "CNTT2024_01", 45, 1.0f, 60, NULL);
            printf("[MOD-2] Created Unassigned Class Section: %s\n", lhp->maLop);
            printf("[MOD-3] Calculating Salary without GV...\n");
            long long tien = calculate_e2e_salary_SAFE(lhp, &cfg);
            export_report_SAFE(lhp->gv_ptr, lhp, tien);
            free(lhp);
            return 0;
        } else if (strcmp(argv[1], "e2e_integer_overflow") == 0) {
            printf("--- E2E TEST SAFE: CWE-190 Integer Overflow Prevented ---\n");
            GiangVien *gv = add_lecturer_SAFE(1, "DU_GV01", "Kylian Mbappe", "GS");
            LopHocPhan *lhp = create_class_section_SAFE(1, "BIG_CLASS_99", 50000, 2.0f, 100, gv);
            long long tien = calculate_e2e_salary_SAFE(lhp, &cfg);
            export_report_SAFE(gv, lhp, tien);
            free(lhp);
            free(gv);
            return 0;
        }
    }

    // Default Interactive Mode
    char name[200], cap[50], malop[50];
    printf("--- DuongUniversity E2E 3-Module System (Safe Version) ---\n");
    printf("[MOD 1] Nhap ho ten giang vien: ");
    if (fgets(name, sizeof(name), stdin) == NULL) return 1;
    name[strcspn(name, "\r\n")] = 0;

    printf("[MOD 1] Nhap bang cap (GS/PGS/TIEN_SI/THAC_SI/CU_NHAN): ");
    if (fgets(cap, sizeof(cap), stdin) == NULL) return 1;
    cap[strcspn(cap, "\r\n")] = 0;

    printf("[MOD 2] Nhap ma lop hoc phan: ");
    if (fgets(malop, sizeof(malop), stdin) == NULL) return 1;
    malop[strcspn(malop, "\r\n")] = 0;

    GiangVien *gv = add_lecturer_SAFE(1, "DU_GV01", name, cap);
    LopHocPhan *lhp = create_class_section_SAFE(1, malop, 45, 1.0f, 60, gv);

    long long tien = calculate_e2e_salary_SAFE(lhp, &cfg);
    export_report_SAFE(gv, lhp, tien);

    free(lhp);
    free(gv);
    return 0;
}
